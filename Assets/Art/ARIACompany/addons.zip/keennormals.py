bl_info = {
	"name": "Keen Normals",
	"description": "Normal tools.",
	"author": "Kurt Loeffler",
	"version": (1, 0, 0),
	"blender": (2, 76, 0),
	"category": "Mesh",
	#"location": "UV Image Editor > UVs > UVs to grid of squares",
	#"warning": "",
	"wiki_url": ""
}

import bpy
import mathutils
import bgl
import copy
import bmesh
from bpy.types import Panel
from rna_prop_ui import PropertyPanel
from collections import namedtuple
from math import sqrt
from math import radians

def load_loops_normals(mesh):
	loop_count = len(mesh.loops)
	loops_normals = [mathutils.Vector((0, 0, 0))]*loop_count
	mesh.calc_normals_split()
	i = 0
	for i in range(len(mesh.loops)):
		l = mesh.loops[i]
		loops_normals[i] = (l.normal.x, l.normal.y, l.normal.z)
	return loops_normals

class AlignNormalsToFaceOp(bpy.types.Operator):
	# face orientation
	bl_idname = 'object.aling_normals_to_face'
	bl_label = 'Align Normals To Face'
	bl_description = 'Align vertices of selected faces to faces normal.'
	bl_options = {"INTERNAL"}

	def execute(self, context):
		obj = context.active_object
		mesh = obj.data

		bpy.ops.object.mode_set(mode='OBJECT')

		bm = bmesh.new()
		bm.from_mesh(mesh)

		mesh.calc_normals_split()
		mesh.free_normals_split()
		normals = load_loops_normals(mesh);

		# Modify the BMesh, can do anything here...
		for vert in bm.verts:
			if not vert.select:
				continue

			normal = mathutils.Vector((0, 0, 0))

			for face in vert.link_faces:
				if not face.select:
					continue
				normal += face.normal

			normal.normalize()

			for loop in vert.link_loops:
				normals[loop.index] = normal

		#bm.to_mesh(mesh)

		obj.data.normals_split_custom_set(normals)

		bpy.ops.object.mode_set(mode='EDIT')

		context.area.tag_redraw()
		return {'FINISHED'}

class KeenNormalsUI(bpy.types.Panel):
	# draw UI buttons
	bl_idname = "KeenNormalsUI_VIEW3D"
	bl_label = "Keen Normals"
	bl_space_type = "VIEW_3D"
	bl_region_type = "TOOLS"
	bl_category = "Shading / UVs"
	def __init__(self):
		pass

	@classmethod
	def poll(self, context):
		try:
			ob = context.active_object
			if ob.type == 'MESH':
				return True
			else:
				return False
		except AttributeError:
			return False

	def draw(self, context):
		is_edit_mode = context.active_object.mode == 'EDIT'

		layout = self.layout
		row = layout.row(align=True)
		row.prop(context.active_object.data, "use_auto_smooth", text="Activate", toggle=True)

		sep = layout.separator()

		row = layout.row(align=True)
		row.active = context.active_object.data.use_auto_smooth
		row.operator('object.aling_normals_to_face', text = "Align To Face")
		row.enabled = is_edit_mode

def register():
	bpy.utils.register_class(KeenNormalsUI)
	bpy.utils.register_class(AlignNormalsToFaceOp)
	#draw_helper_callback_enable()

def unregister():
	bpy.utils.unregister_class(KeenNormalsUI)
	bpy.utils.unregister_class(AlignNormalsToFaceOp)
	#draw_helper_callback_disable()

if __name__ == "__main__":
	register()
