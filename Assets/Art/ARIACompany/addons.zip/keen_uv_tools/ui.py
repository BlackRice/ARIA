import bpy
import math
from . import manipulator

class MainUIPanel(bpy.types.Panel):
	# draw UI buttons
	bl_idname = "keen_uv_tools.main_ui_panel"
	bl_label = "Keen UV Tools"
	bl_space_type = "IMAGE_EDITOR"
	bl_region_type = "TOOLS"
	bl_category = "Tools"

	def __init__(self):
		pass

	@classmethod
	def poll(self, context):
		if not context.mode == 'EDIT_MESH':
			return False
		return True

	def draw(self, context):
		layout = self.layout

		row = layout.row(align=True)
		row.active = not manipulator.UVManipulator.is_running

		row.operator('keen_uv_tools.uv_manipulator', text = "UV Manipulator", icon='CURVE_NCIRCLE')

		col = layout.column(align=True)
		col.operator('keen_uv_tools.align_island_edge', text = "Align Island Edge", icon='MOD_WIREFRAME')

		row = col.row(align=True)
		rot_left = row.operator('transform.rotate', text = "Rotate Left", icon='LOOP_BACK')
		rot_left.value = math.radians(90)
		rot_left.axis = (0, 0, 1)

		rot_right = row.operator('transform.rotate', text = "Rotate Right", icon='LOOP_FORWARDS')
		rot_right.value = math.radians(-90)
		rot_right.axis = (0, 0, 1)

		row = col.row(align=True)
		flip_x = row.operator('transform.resize', text = "Mirror X", icon='MOD_MIRROR')
		flip_x.value = (-1, -1, -1)
		flip_x.constraint_axis = (True, False, False)

		flip_y = row.operator('transform.resize', text = "Mirror Y", icon='MOD_MIRROR')
		flip_y.value = (-1, -1, -1)
		flip_y.constraint_axis = (False, True, False)

		row = col.split(percentage=0.5, align=True)
		straighten = row.operator('uv.align', text = "Straighten", icon='LATTICE_DATA')
		straighten.axis = "ALIGN_S"
		row = row.split(percentage=0.5, align=True)
		straighten_x = row.operator('uv.align', text = "X")
		straighten_x.axis = "ALIGN_X"
		straighten_x = row.operator('uv.align', text = "Y")
		straighten_x.axis = "ALIGN_Y"

		col = layout.column(align=True)

		row = col.row(align=True)
		row.operator('uv.select_linked', text = "Linked")
		row.operator('uv.select_more', text = "More")
		row.operator('uv.select_less', text = "Less")

		row = col.row(align=True)
		row.operator('uv.remove_doubles', text = "Remove Doubles")
		row.operator('uv.weld', text = "Weld")

		row = col.row(align=True)
		row.operator('uv.average_islands_scale', text = "Average Islands")
		row.operator('uv.pack_islands', text = "Pack Islands")

		row = col.row(align=True)
		row.operator('uv.stitch', text = "Stitch")

		col = layout.column(align=True)
		col.menu("VIEW3D_MT_uv_map", text="Unwrap")
		row = col.row(align=True)
		row.operator("mesh.mark_seam").clear = False
		row.operator("mesh.mark_seam", text="Clear Seam").clear = True

		col = layout.column(align=True)
		row = col.row(align=True)
		row.operator('image.reload', text = "Reload Image", icon='FILE_REFRESH')

		layout = layout.separator()