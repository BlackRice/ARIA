bl_info = {
	"name": "Keen UV Tools",
	"description": "Adds some useful uv mapping tools to the uv editor.",
	"author": "Kurt Loeffler",
	"version": (0, 1),
	"blender": (2, 76),
	"category": "Mesh",
	"wiki_url": ""
}

import bpy

modules = locals()

def reload(module_name):
	import importlib
	try:
		importlib.reload(modules[module_name])
		return True
	except KeyError:
		return False

if not reload('manipulator'): from . import manipulator
if not reload('align_island_edge'): from . import align_island_edge
if not reload('utility'): from . import utility
if not reload('ui'): from . import ui

del modules

addon_keymaps = []

def register():
	bpy.utils.register_class(manipulator.UVManipulator)
	bpy.utils.register_class(align_island_edge.AlignIslandEdge)

	bpy.utils.register_class(ui.MainUIPanel)

	#bpy.types.IMAGE_PT_tools_transform_uvs.prepend(ui.draw_prepended_transform_ui)

	wm = bpy.context.window_manager
	km = wm.keyconfigs.addon.keymaps.new(name='UV Editor', space_type='EMPTY')
	kmi = km.keymap_items.new(manipulator.UVManipulator.bl_idname, 'W', 'PRESS', ctrl=True)
	addon_keymaps.append((km, kmi))

def unregister():
	bpy.utils.unregister_class(manipulator.UVManipulator)
	bpy.utils.unregister_class(align_island_edge.AlignIslandEdge)

	bpy.utils.unregister_class(ui.MainUIPanel)

	#bpy.types.IMAGE_PT_tools_transform_uvs.remove(ui.draw_prepended_transform_ui)

	for km, kmi in addon_keymaps:
		km.keymap_items.remove(kmi)
	addon_keymaps.clear()

if __name__ == "__main__":
	register()
