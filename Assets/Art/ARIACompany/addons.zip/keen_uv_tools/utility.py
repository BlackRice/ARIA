
import bpy
import bmesh

def common_elements(list0, list1):
	common = []
	for v0 in list0:
		for v1 in list1:
			if v0 == v1:
				common.append(v0)
	return common

def enter_object_mode():
	bpy.ops.object.mode_set(mode='OBJECT')

def enter_edit_mode():
	bpy.ops.object.mode_set(mode='EDIT')

def get_bmesh(mesh):
	bm = bmesh.new()
	bm.from_mesh(mesh)
	return bm

def get_active_uv_layer(bm, verify = True):
	uv_layer = bm.loops.layers.uv.active
	if verify:
		uv_layer = bm.loops.layers.uv.verify()
	return uv_layer

def get_face_loop_by_vertex(face, vertex):
	for loop in face.loops:
		if loop.vert == vertex:
			return loop
	return None

def get_neighbor_faces(face, limit_selected_faces = False):
	neighbors = []
	for edge in face.edges:
		for f in edge.link_faces:
			if limit_selected_faces and not f.select:
				continue
			if not f == face:
				neighbors.append(f)
	return neighbors

def get_neighbor_uv_faces(uv_layer, face, limit_selected_faces = False):
	neighbors = []

	for edge in face.edges:
		v0_loop = get_face_loop_by_vertex(face, edge.verts[0])
		v1_loop = get_face_loop_by_vertex(face, edge.verts[1])

		v0_loop_uv = v0_loop[uv_layer]
		v1_loop_uv = v1_loop[uv_layer]

		for f in edge.link_faces:
			if limit_selected_faces and not f.select:
				continue
			if not f == face:
				f_v0_loop = get_face_loop_by_vertex(f, edge.verts[0])
				f_v1_loop = get_face_loop_by_vertex(f, edge.verts[1])

				f_v0_loop_uv = f_v0_loop[uv_layer]
				f_v1_loop_uv = f_v1_loop[uv_layer]

				if v0_loop_uv.uv == f_v0_loop_uv.uv and v1_loop_uv.uv == f_v1_loop_uv.uv:
					neighbors.append(f)

	return neighbors

def get_uv_island_faces(bm, uv_layer, root_face, limit_selected_faces = False):
	open_set = []
	open_set.append(root_face)

	island_set = []

	while True:
		new_open_set = []

		for face in open_set:
			island_set.append(face)

		for face in open_set:
			neighbors = get_neighbor_uv_faces(uv_layer, face, limit_selected_faces)
			for n in neighbors:
				if (n not in new_open_set) and (n not in island_set):
					new_open_set.append(n)

		open_set = new_open_set

		if len(open_set) <= 0:
			break

	return island_set

def get_uv_bounds(bm, uv_loops):
	if len(uv_loops) <= 0:
		return None

	minx = uv_loops[0].uv.x
	miny = uv_loops[0].uv.y
	maxx = minx
	maxy = miny

	for uv in uv_loops:
		minx = min(minx, uv.uv.x)
		miny = min(miny, uv.uv.y)
		maxx = max(maxx, uv.uv.x)
		maxy = max(maxy, uv.uv.y)

	return (minx, miny, maxx, maxy)

def get_edge_between_faces(face0, face1):
	for edge in face0.edges:
		if edge in face1.edges:
			return edge
	return None

def loops_to_edges(loops, enclosed = False):
	edges = []
	faces = []
	for loop in loops:
		if loop.face not in faces:
			faces.append(loop.face)

	if enclosed:
		for face0 in faces:
			for edge in face0.edges:
				if not edge in edges:
					lf0v0 = get_face_loop_by_vertex(face0, edge.verts[0])
					lf0v1 = get_face_loop_by_vertex(face0, edge.verts[1])
					if not (lf0v0 in loops and lf0v1 in loops):
						continue
					edges.append(edge)
	else:
		for loop in loops:
			edge = loop.edge
			if edge not in edges:
				edges.append(edge)
	return edges

def is_edge_uv_split(edge, uv_layer):
	if len(edge.link_faces) <= 1:
		return True
	for face0 in edge.link_faces:
		for face1 in edge.link_faces:
			if face0 == face1:
				continue
			f0l0 = get_face_loop_by_vertex(face0, edge.verts[0])
			f0l1 = get_face_loop_by_vertex(face0, edge.verts[1])
			f1l0 = get_face_loop_by_vertex(face1, edge.verts[0])
			f1l1 = get_face_loop_by_vertex(face1, edge.verts[1])
			f0l0uv = f0l0[uv_layer]
			f0l1uv = f0l1[uv_layer]
			f1l0uv = f1l0[uv_layer]
			f1l1uv = f1l1[uv_layer]

			if f0l0uv.uv != f1l0uv.uv or f0l1uv.uv != f1l1uv.uv:
				return True
	return False


def get_selected_uv_loops(bm, uv_layer, limit_selected_faces = False):
	selected_loops = []
	for f in bm.faces:
		if limit_selected_faces and not f.select:
			continue
		for loop in f.loops:
			loop_uv = loop[uv_layer]
			if loop_uv.select:
				selected_loops.append(loop)
	return selected_loops
