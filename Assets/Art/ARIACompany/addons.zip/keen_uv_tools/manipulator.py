
import bpy
import bgl
import bmesh
from mathutils import Vector
from . import utility

def get_mouse_over_state(self, context):
	view_mouse_pos = Vector(context.region.view2d.region_to_view(self.mouse_pos.x, self.mouse_pos.y))

	bottom_left = Vector((self.bounds[0], self.bounds[1]))
	top_left = Vector((self.bounds[0], self.bounds[3]))
	top_right = Vector((self.bounds[2], self.bounds[3]))
	bottom_right = Vector((self.bounds[2], self.bounds[1]))

	px_bottom_left = Vector(context.region.view2d.view_to_region(bottom_left.x, bottom_left.y, False))
	px_top_left = Vector(context.region.view2d.view_to_region(top_left.x, top_left.y, False))
	px_top_right = Vector(context.region.view2d.view_to_region(top_right.x, top_right.y, False))
	px_bottom_right = Vector(context.region.view2d.view_to_region(bottom_right.x, bottom_right.y, False))

	dist_from_left_edge = self.mouse_pos.x-px_bottom_left.x
	dist_from_right_edge = self.mouse_pos.x-px_bottom_right.x
	dist_from_top_edge = self.mouse_pos.y-px_top_left.y
	dist_from_bottom_edge = self.mouse_pos.y-px_bottom_left.y

	if self.mouse_pos.x < 0 or self.mouse_pos.x >= context.region.width or self.mouse_pos.y < 0 or self.mouse_pos.y >= context.region.height:
		return "OUTSIDE_VIEW"

	if (self.mouse_pos-px_bottom_left).magnitude < 6:
		return "BOTTOM_LEFT"
	elif (self.mouse_pos-px_top_left).magnitude < 6:
		return "TOP_LEFT"
	elif (self.mouse_pos-px_top_right).magnitude < 6:
		return "TOP_RIGHT"
	elif (self.mouse_pos-px_bottom_right).magnitude < 6:
		return "BOTTOM_RIGHT"
	elif abs(dist_from_left_edge) < 6 and dist_from_top_edge < 0 and dist_from_bottom_edge > 0:
		return "LEFT"
	elif abs(dist_from_right_edge) < 6 and dist_from_top_edge < 0 and dist_from_bottom_edge > 0:
		return "RIGHT"
	elif abs(dist_from_top_edge) < 6 and dist_from_left_edge > 0 and dist_from_right_edge < 0:
		return "TOP"
	elif abs(dist_from_bottom_edge) < 6 and dist_from_left_edge > 0 and dist_from_right_edge < 0:
		return "BOTTOM"
	elif is_inside_bounds(self.bounds, view_mouse_pos):
		return "INSIDE"
	else:
		return "OUTSIDE"

def draw_bounding_box(bb, poly=True):
	bgl.glBegin(bgl.GL_QUADS if poly else bgl.GL_LINE_LOOP)
	bgl.glVertex2f(bb[0], bb[1])
	bgl.glVertex2f(bb[2], bb[1])
	bgl.glVertex2f(bb[2], bb[3])
	bgl.glVertex2f(bb[0], bb[3])
	bgl.glEnd()

def draw_box(pos, size, poly=True):
	minx = pos.x-(size.x/2)
	miny = pos.y-(size.y/2)
	maxx = pos.x+(size.x/2)
	maxy = pos.y+(size.y/2)
	bb = (minx, miny, maxx, maxy)
	draw_bounding_box(bb, poly)

def draw_line(p0, p1):
	bgl.glBegin(bgl.GL_LINES)
	bgl.glVertex2f(p0.x, p0.y)
	bgl.glVertex2f(p1.x, p1.y)
	bgl.glEnd()

def draw_stipple_line(p0, p1, stipple_size, stipple_pattern, bgcolor, color):
	bgl.glColor4f(bgcolor[0], bgcolor[1], bgcolor[2], bgcolor[3])
	draw_line(p0, p1)
	bgl.glPushAttrib(bgl.GL_ENABLE_BIT)
	bgl.glLineStipple(stipple_size, stipple_pattern)
	bgl.glEnable(bgl.GL_LINE_STIPPLE)
	bgl.glColor4f(color[0], color[1], color[2], color[3])
	draw_line(p0, p1)
	bgl.glPopAttrib()

def is_inside_bounds(bounds, point):
	return point.x >= bounds[0] and point.x < bounds[2] and point.y >= bounds[1] and point.y < bounds[3]

class UVManipulator(bpy.types.Operator):
	bl_idname = "keen_uv_tools.uv_manipulator"
	bl_label = "UV Manipulator"
	bl_options = {'REGISTER', 'UNDO'}

	is_running = False
	handle = None

	def draw_callback_view(self, context):
		bgl.glEnable(bgl.GL_BLEND)

		space = context.area.spaces[0]

		aspect = 1
		if not (space.image is None):
			aspect = space.image.display_aspect.x/space.image.display_aspect.y

		px_pos0 = Vector(context.region.view2d.view_to_region(0, 0, False))
		px_pos1 = Vector(context.region.view2d.view_to_region(0, 1, False))
		pixels_per_unit = px_pos1.y-px_pos0.y

		bottom_left = Vector((self.bounds[0], self.bounds[1]))
		top_left = Vector((self.bounds[0], self.bounds[3]))
		top_right = Vector((self.bounds[2], self.bounds[3]))
		bottom_right = Vector((self.bounds[2], self.bounds[1]))

		mouse_over_state = get_mouse_over_state(self, context)

		if not self.is_dragging:
			if mouse_over_state == "INSIDE":
				bgl.glColor4f(1.0, 1.0, 1.0, 0.2)
				draw_bounding_box(self.bounds)

			bounds_bgcolor = (1.0, 1.0, 1.0, 0.5)
			bounds_active_bgcolor = (1.0, 1.0, 1.0, 1.0)
			bounds_color = (0.0, 0.0, 0.0, 0.5)
			bounds_active_color = (0.0, 0.0, 0.0, 1.0)

			bgl.glLineWidth(2)
			draw_stipple_line(bottom_left, top_left, 3, 0x9999, bounds_active_bgcolor if mouse_over_state == "LEFT" else bounds_bgcolor, bounds_active_color if mouse_over_state == "LEFT" else bounds_color)
			draw_stipple_line(bottom_right, top_right, 3, 0x9999, bounds_active_bgcolor if mouse_over_state == "RIGHT" else bounds_bgcolor, bounds_active_color if mouse_over_state == "RIGHT" else bounds_color)
			draw_stipple_line(top_left, top_right, 3, 0x9999, bounds_active_bgcolor if mouse_over_state == "TOP" else bounds_bgcolor, bounds_active_color if mouse_over_state == "TOP" else bounds_color)
			draw_stipple_line(bottom_left, bottom_right, 3, 0x9999, bounds_active_bgcolor if mouse_over_state == "BOTTOM" else bounds_bgcolor, bounds_active_color if mouse_over_state == "BOTTOM" else bounds_color)

			box_size = 8.0/pixels_per_unit
			box_inset_size = 4.0/pixels_per_unit
			box_size_vector = Vector((box_size/aspect, box_size))
			box_inset_size_vector = Vector((box_inset_size/aspect, box_inset_size))

			bgl.glColor4f(1.0, 1.0, 1.0, 1.0)

			corner_color_0 = (0.2, 0.2, 0.2, 1)
			corner_active_color_0 = (0.0, 0.0, 0.0, 1)

			corner_color_1 = (0.8, 0.8, 0.8, 1)
			corner_active_color_1 = (1.0, 1.0, 1.0, 1)

			bgl.glColor4f(*(corner_active_color_0 if mouse_over_state == "BOTTOM_LEFT" else corner_color_0))
			draw_box(bottom_left, box_size_vector)
			bgl.glColor4f(*(corner_active_color_0 if mouse_over_state == "TOP_LEFT" else corner_color_0))
			draw_box(top_left, box_size_vector)
			bgl.glColor4f(*(corner_active_color_0 if mouse_over_state == "TOP_RIGHT" else corner_color_0))
			draw_box(top_right, box_size_vector)
			bgl.glColor4f(*(corner_active_color_0 if mouse_over_state == "BOTTOM_RIGHT" else corner_color_0))
			draw_box(bottom_right, box_size_vector)

			bgl.glColor4f(*(corner_active_color_1 if mouse_over_state == "BOTTOM_LEFT" else corner_color_1))
			draw_box(bottom_left, box_inset_size_vector)
			bgl.glColor4f(*(corner_active_color_1 if mouse_over_state == "TOP_LEFT" else corner_color_1))
			draw_box(top_left, box_inset_size_vector)
			bgl.glColor4f(*(corner_active_color_1 if mouse_over_state == "TOP_RIGHT" else corner_color_1))
			draw_box(top_right, box_inset_size_vector)
			bgl.glColor4f(*(corner_active_color_1 if mouse_over_state == "BOTTOM_RIGHT" else corner_color_1))
			draw_box(bottom_right, box_inset_size_vector)

			bgl.glLineWidth(1)
			bgl.glColor4f(1.0, 1.0, 1.0, 1.0)

		self.last_mouse_pos = (self.mouse_pos.x, self.mouse_pos.x)

	def update_selection_bounds(self, context):
		obj = context.active_object
		mesh = obj.data

		utility.enter_object_mode()
		bm = utility.get_bmesh(mesh)
		uv_layer = utility.get_active_uv_layer(bm)
		selected_loops = utility.get_selected_uv_loops(bm, uv_layer, limit_selected_faces = True)
		selected_uvs = [loop[uv_layer] for loop in selected_loops]
		b = utility.get_uv_bounds(bm, selected_uvs)
		utility.enter_edit_mode()

		if b is None:
			return False

		if b[0] == b[2] and b[1] == b[3]:
			return False

		self.bounds = b
		return True

	def close(self):
		if not (self.handle is None):
			bpy.types.SpaceImageEditor.draw_handler_remove(self.handle, 'WINDOW')
		bpy.context.window.cursor_modal_restore()
		UVManipulator.is_running = False
		return {'CANCELLED'}

	def redraw(self, context):
		context.area.tag_redraw()

	@classmethod
	def poll(cls, context):
		if UVManipulator.is_running:
			return False
		if not context.mode == 'EDIT_MESH':
			return False
		return True

	def modal(self, context, event):
		if not isinstance(self, UVManipulator):
			#This has happened O_o
			return self.close()

		self.redraw(context)

		space = context.area.spaces[0]

		update_bounds = False

		if event.type == "Z" and event.ctrl:
			update_bounds = True

		if self.is_dragging:
			self.is_dragging = False

		if self.last_active_operator != bpy.context.active_operator:
			update_bounds = True
		self.last_active_operator = bpy.context.active_operator

		if update_bounds:
			if (not self.update_selection_bounds(context)):
				return self.close()

		move_type_name = "LEFTMOUSE"
		cancel_mouse_type_name = "RIGHTMOUSE"

		mouse_over_state = get_mouse_over_state(self, context)

		if mouse_over_state == "BOTTOM_LEFT":
			bpy.context.window.cursor_modal_set("CROSSHAIR")
		elif mouse_over_state == "TOP_LEFT":
			bpy.context.window.cursor_modal_set("CROSSHAIR")
		elif mouse_over_state == "TOP_RIGHT":
			bpy.context.window.cursor_modal_set("CROSSHAIR")
		elif mouse_over_state == "BOTTOM_RIGHT":
			bpy.context.window.cursor_modal_set("CROSSHAIR")
		elif mouse_over_state == "LEFT":
			bpy.context.window.cursor_modal_set("MOVE_X")
		elif mouse_over_state == "RIGHT":
			bpy.context.window.cursor_modal_set("MOVE_X")
		elif mouse_over_state == "TOP":
			bpy.context.window.cursor_modal_set("MOVE_Y")
		elif mouse_over_state == "BOTTOM":
			bpy.context.window.cursor_modal_set("MOVE_Y")
		elif mouse_over_state == "INSIDE":
			bpy.context.window.cursor_modal_set("HAND")
		elif mouse_over_state == "OUTSIDE":
			bpy.context.window.cursor_modal_set("SCROLL_XY")
		elif mouse_over_state == "OUTSIDE_VIEW":
			bpy.context.window.cursor_modal_set("DEFAULT")

		if event.type == 'MOUSEMOVE':
			self.mouse_pos = Vector((event.mouse_region_x, event.mouse_region_y))

		elif event.type == move_type_name and event.value == "PRESS":
			if mouse_over_state == "OUTSIDE_VIEW":
				return {'PASS_THROUGH'}

			if self.mouse_down:
				self.mouse_down = False

			else:
				self.mouse_down = True
				view_mouse_pos = Vector(context.region.view2d.region_to_view(self.mouse_pos.x, self.mouse_pos.y))

				bottom_left = Vector((self.bounds[0], self.bounds[1]))
				top_left = Vector((self.bounds[0], self.bounds[3]))
				top_right = Vector((self.bounds[2], self.bounds[3]))
				bottom_right = Vector((self.bounds[2], self.bounds[1]))

				previous_pivot_point = space.pivot_point
				previous_cursor_location = space.cursor_location.copy()

				image_width = 256
				image_height = 256

				if not (space.image is None):
					image_width = space.image.size[0]
					image_height = space.image.size[1]

				if space.uv_editor.show_normalized_coords:
					image_width = 1
					image_height = 1

				cursor_or_center = "CURSOR"
				if event.shift:
					cursor_or_center = "CENTER"
				else:
					cursor_or_center = "CURSOR"

				if mouse_over_state == "BOTTOM_LEFT":
					space.pivot_point = cursor_or_center
					space.cursor_location = (top_right.x*image_width, top_right.y*image_height);
					bpy.ops.transform.resize('INVOKE_DEFAULT', release_confirm = True)
				elif mouse_over_state == "TOP_LEFT":
					space.pivot_point = cursor_or_center
					space.cursor_location = (bottom_right.x*image_width, bottom_right.y*image_height);
					bpy.ops.transform.resize('INVOKE_DEFAULT', release_confirm = True)
				elif mouse_over_state == "TOP_RIGHT":
					space.pivot_point = cursor_or_center
					space.cursor_location = (bottom_left.x*image_width, bottom_left.y*image_height);
					bpy.ops.transform.resize('INVOKE_DEFAULT', release_confirm = True)
					space.pivot_point = "MEDIAN"
				elif mouse_over_state == "BOTTOM_RIGHT":
					space.pivot_point = cursor_or_center
					space.cursor_location = (top_left.x*image_width, top_left.y*image_height);
					bpy.ops.transform.resize('INVOKE_DEFAULT', release_confirm = True)
				elif mouse_over_state == "LEFT":
					space.pivot_point = cursor_or_center
					space.cursor_location = (top_right.x*image_width, view_mouse_pos.y*image_height);
					bpy.ops.transform.resize('INVOKE_DEFAULT', constraint_axis = (True, False, False), release_confirm = True)
				elif mouse_over_state == "RIGHT":
					space.pivot_point = cursor_or_center
					space.cursor_location = (bottom_left.x*image_width, view_mouse_pos.y*image_height);
					bpy.ops.transform.resize('INVOKE_DEFAULT', constraint_axis = (True, False, False), release_confirm = True)
				elif mouse_over_state == "TOP":
					space.pivot_point = cursor_or_center
					space.cursor_location = (view_mouse_pos.x*image_width, bottom_left.y*image_height);
					bpy.ops.transform.resize('INVOKE_DEFAULT', constraint_axis = (False, True, False), release_confirm = True)
				elif mouse_over_state == "BOTTOM":
					space.pivot_point = cursor_or_center
					space.cursor_location = (view_mouse_pos.x*image_width, top_left.y*image_height);
					bpy.ops.transform.resize('INVOKE_DEFAULT', constraint_axis = (False, True, False), release_confirm = True)
				elif mouse_over_state == "INSIDE":
					bpy.ops.transform.translate('INVOKE_DEFAULT', release_confirm = True)
				elif mouse_over_state == "OUTSIDE":
					space.pivot_point = "CENTER"
					bpy.ops.transform.rotate('INVOKE_DEFAULT', release_confirm = True)

				space.pivot_point = previous_pivot_point
				space.cursor_location = previous_cursor_location

				self.is_dragging = True
				self.mouse_down = False

			return {'RUNNING_MODAL'}

		elif event.type in {cancel_mouse_type_name, 'ESC'}:
			return self.close()

		return {'PASS_THROUGH'}
		#return {'RUNNING_MODAL'}

	def invoke(self, context, event):
		if context.area.type == 'IMAGE_EDITOR':

			if (bpy.context.scene.tool_settings.use_uv_select_sync):
				self.report({'ERROR'}, "The UV manipulator does not support \"Keep UV and edit mode mesh selection in sync\" option in the UV editor. Turn it off and try again.")
				return self.close()

			if (not self.update_selection_bounds(context)):
				return self.close()

			self.mouse_pos = Vector((event.mouse_region_x, event.mouse_region_y))
			self.last_mouse_pos = Vector((self.mouse_pos.x, self.mouse_pos.y))
			self.mouse_down = False
			self.is_dragging = False
			self.last_active_operator = None

			UVManipulator.is_running = True
			context.window_manager.modal_handler_add(self)
			self.handle = bpy.types.SpaceImageEditor.draw_handler_add(self.draw_callback_view, (context,), 'WINDOW', 'POST_VIEW')

			return {'RUNNING_MODAL'}
		else:
			self.report({'WARNING'}, "IMAGE_EDITOR not found.")
			return self.close()
