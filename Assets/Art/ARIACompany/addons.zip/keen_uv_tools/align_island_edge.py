import bpy
import bmesh
from mathutils import (Vector, Quaternion, Matrix)
from . import utility

class AlignIslandEdge(bpy.types.Operator):
	bl_idname = "keen_uv_tools.align_island_edge"
	bl_label = "Align Island Edge"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(cls, context):
		if not context.mode == 'EDIT_MESH':
			return False
		return True

	def invoke(self, context, event):
		utility.enter_object_mode()

		obj = context.active_object
		mesh = obj.data
		active_face_index = mesh.polygons.active

		bm = utility.get_bmesh(mesh)
		uv_layer = utility.get_active_uv_layer(bm)
		bm.faces.ensure_lookup_table()

		selected_uv_loops = utility.get_selected_uv_loops(bm, uv_layer, limit_selected_faces = False)
		selected_uv_edges = utility.loops_to_edges(selected_uv_loops, enclosed = True)
		filtered_edges = []
		for edge in selected_uv_edges:
			if edge.select:
				filtered_edges.append(edge)

		selected_uv_edges = filtered_edges

		if len(selected_uv_edges) < 1:
			utility.enter_edit_mode()
			self.report({'ERROR'}, "Must select a uv edge.")
			return {'CANCELLED'}

		class EdgeInfo():
			edge = None
			face = None

		class Island():
			edges = None
			faces = None

		islands = []

		for edge in selected_uv_edges:
			edge_info = EdgeInfo()
			edge_info.edge = edge

			for f in edge.link_faces:
				l0 = utility.get_face_loop_by_vertex(f, edge.verts[0])
				l1 = utility.get_face_loop_by_vertex(f, edge.verts[1])
				if (not l0 in selected_uv_loops or not l1 in selected_uv_loops):
					continue
				edge_info.face = f

			island = None
			for i in islands:
				if edge_info.face in i.faces:
					island = i
					break

			if island is None:
				island = Island()
				island.edges = []
				island.faces = utility.get_uv_island_faces(bm, uv_layer, edge_info.face, limit_selected_faces = True)
				islands.append(island)

			island.edges.append(edge_info)

		for island in islands:
			edge_info = island.edges[0]

			loop_0 = utility.get_face_loop_by_vertex(edge_info.face, edge_info.edge.verts[0])
			loop_1 = utility.get_face_loop_by_vertex(edge_info.face, edge_info.edge.verts[1])

			loop_uv_0 = loop_0[uv_layer]
			loop_uv_1 = loop_1[uv_layer]

			pos_0 = loop_uv_0.uv.copy()
			pos_1 = loop_uv_1.uv.copy()
			pos_0.resize_3d()
			pos_1.resize_3d()

			diff_vector = pos_0-pos_1
			diff_normal = diff_vector.copy()
			diff_normal.normalize()

			target_vector = Vector((1, 0, 0))
			dot = target_vector.dot(diff_normal)
			if Vector((-1, 0, 0)).dot(diff_normal) > dot:
				dot = Vector((-1, 0, 0)).dot(diff_normal)
				target_vector = Vector((-1, 0, 0))
			if Vector((0, 1, 0)).dot(diff_normal) > dot:
				dot = Vector((0, 1, 0)).dot(diff_normal)
				target_vector = Vector((0, 1, 0))
			if Vector((0, -1, 0)).dot(diff_normal) > dot:
				dot = Vector((0, -1, 0)).dot(diff_normal)
				target_vector = Vector((0, -1, 0))

			translate_matrix = Matrix.Translation(pos_0)

			rot_diff = diff_normal.rotation_difference(target_vector)
			rot_matrix = rot_diff.to_matrix()
			rot_matrix.resize_4x4()

			matrix = translate_matrix*rot_matrix*translate_matrix.inverted()

			for face in island.faces:
				for loop in face.loops:
					loop_uv = loop[uv_layer]
					uv = loop_uv.uv.copy()
					uv.resize_3d()
					uv = matrix*uv
					uv.resize_2d()
					loop_uv.uv = uv

		bm.to_mesh(mesh)

		utility.enter_edit_mode()

		return {'FINISHED'}
